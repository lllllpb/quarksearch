require('dotenv').config();
const GyingScraper = require('../scraper');

(async () => {
  const keyword = process.argv.slice(2).join(' ') || '海绵宝宝';
  if (!process.env.SITE_USER || !process.env.SITE_PASS) {
    throw new Error('SITE_USER and SITE_PASS are required');
  }

  const scraper = new GyingScraper();
  await scraper.init();
  try {
    await scraper.accessSite();
    await scraper.login(process.env.SITE_USER, process.env.SITE_PASS);
    const { results, categories } = await scraper.search(keyword);
    console.log(JSON.stringify({ keyword, count: results.length, categories, first: results[0] }, null, 2));

    if (results[0]) {
      const links = await scraper.getQuarkLinks(results[0].url);
      console.log(JSON.stringify({ quarkCount: links.length, firstLinks: links.slice(0, 3) }, null, 2));
    }
  } finally {
    await scraper.close();
  }
})().catch(error => {
  console.error(error.stack || error.message);
  process.exit(1);
});
