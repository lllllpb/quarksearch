const { chromium } = require('playwright');

class GyingScraper {
  constructor() {
    this.browser = null;
    this.context = null;
    this.page = null;
    this.loggedIn = false;
  }

  async init() {
    const browserlessEndpoint = process.env.BROWSERLESS_WS_ENDPOINT;

    if (browserlessEndpoint) {
      this.browser = await chromium.connectOverCDP(browserlessEndpoint);
      this.context = this.browser.contexts()[0] || await this.browser.newContext({
        userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36'
      });
    } else {
      this.browser = await chromium.launch({
        headless: true,
        args: ['--no-sandbox', '--disable-setuid-sandbox']
      });
      this.context = await this.browser.newContext({
        userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36'
      });
    }

    this.page = await this.context.newPage();
    this.page.setDefaultTimeout(30000);
  }

  async log(msg) { console.log(`[${new Date().toISOString()}] ${msg}`); }

  // Step 1: Navigate to gying.net, get mirror, and access it (handle PoW)
  async accessSite() {
    this.log('Accessing gying.net...');
    await this.page.goto('https://www.gying.net/', { waitUntil: 'networkidle', timeout: 30000 });
    
    // Click "获取新网址"
    await this.page.click('#CButton');
    await this.page.waitForTimeout(2000);
    
    // Get mirror links
    const mirrors = await this.page.$$eval('#goooo a', els => els.map(e => e.href));
    if (mirrors.length === 0) throw new Error('No mirrors found');
    
    this.log(`Found ${mirrors.length} mirrors, trying first: ${mirrors[0]}`);
    await this.page.goto(mirrors[0], { waitUntil: 'networkidle', timeout: 60000 });
    
    // Wait for PoW verification (may take 10-20 seconds)
    await this.page.waitForTimeout(15000);
    
    // Check if we're on the actual site by looking for login link
    const loginLink = await this.page.$('a:has-text("登录")');
    if (!loginLink) {
      // Retry with another mirror
      this.log('First mirror failed, trying second...');
      await this.page.goto(mirrors[1], { waitUntil: 'networkidle', timeout: 60000 });
      await this.page.waitForTimeout(15000);
    }
    
    const title = await this.page.title();
    this.log(`Site accessed: ${title}`);
    return true;
  }

  // Step 2: Login
  async login(username, password) {
    if (this.loggedIn) return true;
    
    this.log('Logging in...');
    
    // Check if login is needed
    const userMenu = await this.page.$('a:has-text("退出登录")');
    if (userMenu) {
      this.log('Already logged in');
      this.loggedIn = true;
      return true;
    }
    
    // Click login link
    await this.page.click('a:has-text("登录")');
    await this.page.waitForTimeout(2000);
    
    // Fill credentials
    await this.page.fill('input[placeholder*="用户名"], input[placeholder*="邮件"]', username);
    await this.page.fill('input[placeholder*="密码"]', password);
    
    // Click login button
    await this.page.click('button:has-text("登录")');
    await this.page.waitForTimeout(3000);
    
    // Verify login
    const errorEl = await this.page.$('.error, .alert-danger');
    if (errorEl) {
      const errText = await errorEl.textContent();
      throw new Error(`Login failed: ${errText}`);
    }
    
    this.loggedIn = true;
    this.log('Login successful');
    return true;
  }

  // Step 3: Search
  async search(keyword) {
    this.log(`Searching: ${keyword}`);
    
    // Navigate to home first to ensure search box is available
    await this.page.goto(this.page.url().split('?')[0], { waitUntil: 'networkidle', timeout: 30000 });
    await this.page.waitForTimeout(1000);
    
    // Close popup if exists
    const closeBtn = await this.page.$('[class*="close"], button:has-text("14天")');
    if (closeBtn) {
      await closeBtn.click().catch(() => {});
      await this.page.waitForTimeout(500);
    }
    
    // Type in search box
    const searchBox = await this.page.$('input[type="search"], input[placeholder*="Search"], input[name="search"]');
    if (!searchBox) throw new Error('Search box not found');
    
    await searchBox.fill('');
    await searchBox.fill(keyword);
    await searchBox.press('Enter');
    await this.page.waitForTimeout(3000);
    
    // Parse search results
    return await this.parseSearchResults();
  }

  // Parse search results page
  async parseSearchResults() {
    return await this.page.evaluate(() => {
      const results = [];
      
      // Find all result links in the main content area
      const mainEl = document.querySelector('main');
      if (!mainEl) return { results: [], categories: {} };
      
      const allLinks = mainEl.querySelectorAll('a');
      
      for (const link of allLinks) {
        const href = link.href;
        const text = link.textContent?.trim() || '';
        
        // Skip non-result links (filter, pagination, etc.)
        if (!text || text.length < 3) continue;
        if (text.includes('更多') || text.includes('下一页') || text.includes('问题反馈')) continue;
        if (/^\d+$/.test(text)) continue; // page numbers
        
        // Detect category from URL pattern or text
        let category = 'unknown';
        if (href.includes('/movie/') || text.includes('电影')) category = 'movie';
        else if (href.includes('/tv/') || text.includes('剧集')) category = 'tv';
        else if (href.includes('/anime/') || text.includes('动漫')) category = 'anime';
        
        // Only include actual content links (with title patterns)
        if (text.length > 5 && href.includes('/') && !href.includes('javascript:')) {
          results.push({
            title: text.substring(0, 100),
            url: href,
            category: category
          });
        }
      }
      
      // Count categories
      const catLinks = mainEl.querySelectorAll('a');
      const categories = { all: results.length };
      catLinks.forEach(a => {
        const t = a.textContent?.trim() || '';
        const match = t.match(/(电影|剧集|动漫|种子|网盘)\s*(\d+)/);
        if (match) categories[match[1]] = parseInt(match[2]);
      });
      
      return { results, categories };
    });
  }

  // Step 4: Filter search results by category
  async filterByCategory(category) {
    this.log(`Filtering by: ${category}`);
    
    const catMap = { '电影': 'movie', '剧集': 'tv', '动漫': 'anime', '种子': 'torrent', '网盘': 'pan' };
    const catText = Object.keys(catMap).find(k => catMap[k] === category) || category;
    
    try {
      const filterLink = await this.page.$(`a:has-text("${catText}")`);
      if (filterLink) {
        await filterLink.click();
        await this.page.waitForTimeout(2000);
      }
    } catch (e) {
      this.log(`Filter click failed: ${e.message}`);
    }
    
    return await this.parseSearchResults();
  }

  // Step 5: Go to detail page and extract quark links
  async getQuarkLinks(url) {
    this.log(`Fetching detail: ${url}`);
    await this.page.goto(url, { waitUntil: 'networkidle', timeout: 30000 });
    await this.page.waitForTimeout(3000);
    
    // Close popups
    const closeBtn = await this.page.$('[class*="close"], button:has-text("14天")');
    if (closeBtn) {
      await closeBtn.click().catch(() => {});
      await this.page.waitForTimeout(500);
    }
    
    // Switch to 网盘资源 tab using JS
    const switched = await this.page.evaluate(() => {
      const li = Array.from(document.querySelectorAll('li')).find(e => e.textContent?.includes('网盘资源'));
      if (li) { li.click(); return true; }
      return false;
    });
    
    if (switched) await this.page.waitForTimeout(2000);
    
    // Extract all 夸克网盘 links
    const quarkLinks = await this.page.evaluate(() => {
      const results = [];
      const tables = document.querySelectorAll('table');
      
      tables.forEach(table => {
        const caption = table.querySelector('caption');
        if (!caption || !caption.textContent.includes('夸克')) return;
        
        const rows = table.querySelectorAll('tbody tr');
        rows.forEach(row => {
          const nameCell = row.querySelector('td:first-child');
          const codeCell = row.querySelector('td:nth-child(2)');
          const link = nameCell?.querySelector('a');
          
          if (link && link.href) {
            results.push({
              name: nameCell.textContent?.trim()?.substring(0, 100) || '',
              url: link.href,
              code: codeCell?.textContent?.trim() || ''
            });
          }
        });
      });
      
      return results;
    });
    
    this.log(`Found ${quarkLinks.length} quark links`);
    return quarkLinks;
  }

  async close() {
    if (this.page && !this.page.isClosed()) {
      await this.page.close().catch(() => {});
    }
    if (this.browser) {
      if (process.env.BROWSERLESS_WS_ENDPOINT && typeof this.browser.close === 'function') {
        // For browserless/CDP this usually disconnects this client; ignore failures so reset can continue.
        await this.browser.close().catch(() => {});
      } else {
        await this.browser.close().catch(() => {});
      }
    }
  }
}

module.exports = GyingScraper;
