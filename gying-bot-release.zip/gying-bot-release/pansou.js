class PansouClient {
  constructor(baseUrl) {
    this.baseUrl = (baseUrl || 'http://192.168.1.145:9981').replace(/\/$/, '');
  }

  async search(keyword, limit = 20) {
    const url = new URL('/api/search', this.baseUrl);
    url.searchParams.set('kw', keyword);

    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 35000);

    try {
      const response = await fetch(url, { signal: controller.signal });
      if (!response.ok) throw new Error(`PanSou HTTP ${response.status}`);
      const payload = await response.json();
      if (payload.code !== 0) throw new Error(payload.message || 'PanSou search failed');

      const data = payload.data || {};
      const merged = data.merged_by_type || {};
      const quark = Array.isArray(merged.quark) ? merged.quark : [];

      const seen = new Set();
      const results = [];
      for (const item of quark) {
        const link = String(item.url || '').trim();
        if (!link || !link.includes('pan.quark.cn') || seen.has(link)) continue;
        seen.add(link);
        results.push({
          name: String(item.note || item.title || '未命名资源').replace(/\s+/g, ' ').trim(),
          url: link,
          code: String(item.password || '').trim(),
          source: String(item.source || '').trim(),
          datetime: String(item.datetime || '').trim(),
        });
        if (results.length >= limit) break;
      }

      return {
        keyword,
        total: data.total || 0,
        quarkCount: quark.length,
        results,
        types: Object.keys(merged),
      };
    } finally {
      clearTimeout(timer);
    }
  }
}

module.exports = PansouClient;
