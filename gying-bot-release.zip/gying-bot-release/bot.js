require('dotenv').config();
const { TelegramBot } = require('node-telegram-bot-api');
const { ProxyAgent, fetch: undiciFetch } = require('undici');
const GyingScraper = require('./scraper');
const PansouClient = require('./pansou');

const BOT_TOKEN = process.env.BOT_TOKEN;
const SITE_USER = process.env.SITE_USER;
const SITE_PASS = process.env.SITE_PASS;
const TELEGRAM_PROXY = process.env.TELEGRAM_PROXY || process.env.HTTPS_PROXY || process.env.HTTP_PROXY || process.env.ALL_PROXY;
const PANSOU_BASE_URL = process.env.PANSOU_BASE_URL || 'http://192.168.1.145:9981';

if (!BOT_TOKEN) {
  console.error('BOT_TOKEN not set in .env');
  process.exit(1);
}

if (!SITE_USER || !SITE_PASS) {
  console.error('SITE_USER and SITE_PASS must be set in .env');
  process.exit(1);
}

const botOptions = { polling: true };
if (TELEGRAM_PROXY) {
  const telegramDispatcher = new ProxyAgent(TELEGRAM_PROXY);
  botOptions.request = {
    fetch: (url, init = {}) => undiciFetch(url, { ...init, dispatcher: telegramDispatcher }),
  };
}
const bot = new TelegramBot(BOT_TOKEN, botOptions);

// Session store: chatId -> { state, results, selectedUrl, category }
const sessions = new Map();
const pansou = new PansouClient(PANSOU_BASE_URL);
const LINK_PAGE_SIZE = Number(process.env.LINK_PAGE_SIZE || 4);

// Shared scraper instance (keep browser open)
let scraper = null;
let scraperReady = false;
let scraperInitPromise = null;
let scraperQueue = Promise.resolve();

function isClosedError(error) {
  const message = String(error?.message || error || '');
  return message.includes('Target page, context or browser has been closed')
    || message.includes('Browser has been closed')
    || message.includes('browserContext.newPage')
    || message.includes('Connection closed')
    || message.includes('WebSocket is not open');
}

async function resetScraper() {
  const oldScraper = scraper;
  scraper = null;
  scraperReady = false;
  scraperInitPromise = null;
  if (oldScraper) {
    await oldScraper.close().catch(() => {});
  }
}

async function withScraperTask(task) {
  const run = async () => {
    let lastError;
    for (let attempt = 0; attempt < 2; attempt++) {
      try {
        const s = await getScraper();
        return await task(s);
      } catch (error) {
        lastError = error;
        if (!isClosedError(error) || attempt === 1) throw error;
        console.warn('Scraper browser/page closed, reconnecting and retrying once:', error.message);
        await resetScraper();
      }
    }
    throw lastError;
  };

  const result = scraperQueue.then(run, run);
  scraperQueue = result.catch(() => {});
  return result;
}

async function getScraper() {
  if (scraperReady) return scraper;
  
  if (!scraperInitPromise) {
    scraperInitPromise = (async () => {
      scraper = new GyingScraper();
      await scraper.init();
      await scraper.accessSite();
      await scraper.login(SITE_USER, SITE_PASS);
      scraperReady = true;
      console.log('Scraper initialized and logged in');
    })().catch(e => {
      console.error('Scraper init failed:', e.message);
      scraperInitPromise = null;
      throw e;
    });
  }
  
  await scraperInitPromise;
  return scraper;
}

// Helper: send results as inline keyboard
async function sendResults(chatId, results, categories, page = 0, perPage = 5) {
  const start = page * perPage;
  const pageResults = results.slice(start, start + perPage);
  const totalPages = Math.ceil(results.length / perPage);
  
  let text = `🔍 搜索结果 共 ${results.length} 个\n`;
  
  // Category stats
  if (categories) {
    text += '\n📂 分类统计:\n';
    for (const [cat, count] of Object.entries(categories)) {
      if (cat === 'all') continue;
      const emoji = { '电影': '🎬', '剧集': '📺', '动漫': '🧸', '种子': '🧲', '网盘': '☁️' }[cat] || '📁';
      text += `${emoji} ${cat}: ${count}\n`;
    }
  }
  
  text += `\n📄 第 ${page + 1}/${totalPages} 页:\n`;
  
  const keyboard = { inline_keyboard: [] };
  
  pageResults.forEach((r, i) => {
    const idx = start + i;
    const shortTitle = r.title.length > 50 ? r.title.substring(0, 47) + '...' : r.title;
    const emoji = r.category === 'movie' ? '🎬' : r.category === 'tv' ? '📺' : r.category === 'anime' ? '🧸' : '📁';
    text += `${idx + 1}. ${emoji} ${shortTitle}\n`;
    
    keyboard.inline_keyboard.push([{
      text: `${idx + 1}. ${shortTitle.substring(0, 30)}`,
      callback_data: `select|${idx}`
    }]);
  });
  
  // Pagination + Category filter row
  const navRow = [];
  if (page > 0) {
    navRow.push({ text: '⬅️ 上一页', callback_data: `page|${page - 1}` });
  }
  if (page < totalPages - 1) {
    navRow.push({ text: '➡️ 下一页', callback_data: `page|${page + 1}` });
  }
  if (navRow.length > 0) keyboard.inline_keyboard.push(navRow);
  
  // Category filter row
  if (categories) {
    const filterRow = [];
    const cats = ['电影', '剧集', '动漫'];
    for (const cat of cats) {
      if (categories[cat] && categories[cat] > 0) {
        const emoji = { '电影': '🎬', '剧集': '📺', '动漫': '🧸' }[cat];
        filterRow.push({
          text: `${emoji} ${cat}`,
          callback_data: `category|${cat}`
        });
      }
    }
    if (filterRow.length > 0) keyboard.inline_keyboard.push(filterRow);
  }
  
  keyboard.inline_keyboard.push([{
    text: '☁️ PanSou补充搜索',
    callback_data: 'pansou|search'
  }]);

  // All results button
  keyboard.inline_keyboard.push([{
    text: '📋 显示全部',
    callback_data: 'category|全部'
  }]);
  
  await bot.sendMessage(chatId, text, { reply_markup: keyboard });
}

// Handle /start
bot.onText(/\/start/, async (msg) => {
  const chatId = msg.chat.id;
  await bot.sendMessage(chatId,
    '🎬 *GYing 网盘搜索机器人*\n\n' +
    '直接发送搜索词，我会帮你查找资源并返回夸克网盘分享链接。\n\n' +
    '例如：发送「海绵宝宝」\n\n' +
    '命令：\n' +
    '/search 关键词 - 搜索 GYing 资源\n' +
    '/pansou 关键词 - 搜索 PanSou 夸克资源\n' +
    '/status - 查看状态',
    { parse_mode: 'Markdown' }
  );
});

// Handle /status
bot.onText(/\/status/, async (msg) => {
  const chatId = msg.chat.id;
  const status = scraperReady ? '✅ 已连接并登录' : '⏳ 正在初始化...';
  await bot.sendMessage(chatId, `状态: ${status}\n会话数: ${sessions.size}`);
});


// Handle /pansou command
bot.onText(/\/pansou\s+(.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const keyword = match[1].trim();
  await handlePansouSearch(chatId, keyword);
});

// Handle /search command
bot.onText(/\/search\s+(.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const keyword = match[1].trim();
  
  await handleSearch(chatId, keyword);
});

// Handle plain text as search
bot.on('message', async (msg) => {
  const chatId = msg.chat.id;
  const text = msg.text?.trim();
  
  // Ignore commands
  if (!text || text.startsWith('/')) return;
  
  await handleSearch(chatId, text);
});

async function handleSearch(chatId, keyword) {
  try {
    const statusMsg = await bot.sendMessage(chatId, `🔍 正在搜索: ${keyword}...`);
    
    const { results, categories } = await withScraperTask(s => s.search(keyword));
    
    if (results.length === 0) {
      await bot.deleteMessage(chatId, statusMsg.message_id);
      await bot.sendMessage(chatId, `❌ 未找到 "${keyword}" 的相关结果`);
      return;
    }
    
    // Store session
    sessions.set(chatId, {
      results,
      categories,
      keyword,
      page: 0,
      state: 'browsing'
    });
    
    await bot.deleteMessage(chatId, statusMsg.message_id);
    await sendResults(chatId, results, categories, 0);
    
  } catch (e) {
    console.error('Search error:', e);
    await bot.sendMessage(chatId, `❌ 搜索失败: ${e.message}\n请稍后重试 /status 查看状态`);
    
    if (isClosedError(e)) await resetScraper();
  }
}


function getPagedLinks(links, page, pageSize = LINK_PAGE_SIZE) {
  const safePage = Math.max(0, Number(page) || 0);
  const start = safePage * pageSize;
  return {
    page: safePage,
    start,
    items: links.slice(start, start + pageSize),
    hasMore: start + pageSize < links.length,
    remaining: Math.max(0, links.length - start - pageSize),
    totalPages: Math.max(1, Math.ceil(links.length / pageSize)),
  };
}

function formatLinkPage({ title, source, links, page = 0 }) {
  if (!links.length) return `${source}${title} 未找到夸克网盘资源。`;
  const data = getPagedLinks(links, page);

  let text = `${source}${title.substring(0, 80)}\n`;
  text += `共 ${links.length} 个夸克链接，当前第 ${data.page + 1}/${data.totalPages} 页，每次返回 ${LINK_PAGE_SIZE} 个。\n\n`;

  data.items.forEach((link, i) => {
    const index = data.start + i + 1;
    text += `${index}. ${String(link.name || '未命名资源').substring(0, 70)}\n`;
    text += `🔗 ${link.url}\n`;
    if (link.code) text += `🔑 提取码: ${link.code}\n`;
    if (link.source) text += `📍 来源: ${link.source}\n`;
    text += '\n';
  });

  text += data.hasMore ? `还有 ${data.remaining} 个，点击下面按钮继续返回。` : '已全部返回。';
  return text;
}

async function sendLinkPage(chatId, key, page = 0) {
  const session = sessions.get(chatId);
  const detail = session?.linkPages?.[key];
  if (!detail) {
    await bot.sendMessage(chatId, '❌ 结果已过期，请重新搜索。');
    return;
  }

  const data = getPagedLinks(detail.links, page);
  const keyboard = { inline_keyboard: [] };
  if (data.hasMore) {
    keyboard.inline_keyboard.push([{
      text: `继续返回 ${Math.min(LINK_PAGE_SIZE, data.remaining)} 个`,
      callback_data: `morelinks|${key}|${page + 1}`,
    }]);
  }

  await bot.sendMessage(chatId, formatLinkPage({ ...detail, page }), {
    disable_web_page_preview: true,
    reply_markup: keyboard.inline_keyboard.length ? keyboard : undefined,
  });
}

async function handlePansouSearch(chatId, keyword) {
  const statusMsg = await bot.sendMessage(chatId, `☁️ 正在用 PanSou 搜索: ${keyword}...`);
  try {
    const summary = await pansou.search(keyword, 40);
    const session = sessions.get(chatId) || {};
    session.keyword = keyword;
    session.linkPages = session.linkPages || {};
    session.linkPages.pansou = {
      title: keyword,
      source: '☁️ PanSou：',
      links: summary.results,
    };
    sessions.set(chatId, session);

    await bot.deleteMessage(chatId, statusMsg.message_id).catch(() => {});
    await sendLinkPage(chatId, 'pansou', 0);
  } catch (error) {
    console.error('PanSou error:', error);
    await bot.deleteMessage(chatId, statusMsg.message_id).catch(() => {});
    await bot.sendMessage(chatId, `❌ PanSou 搜索失败: ${String(error.message || error).slice(0, 300)}`);
  }
}

// Handle inline keyboard callbacks
bot.on('callback_query', async (query) => {
  const chatId = query.message.chat.id;
  const msgId = query.message.message_id;
  const data = query.data;
  
  await bot.answerCallbackQuery(query.id);
  
  try {
    const [action, ...args] = data.split('|');
    
    if (action === 'morelinks') {
      const key = args[0];
      const page = Number(args[1] || 0);
      await sendLinkPage(chatId, key, page);

    } else if (action === 'pansou') {
      const session = sessions.get(chatId);
      if (!session?.keyword) {
        await bot.sendMessage(chatId, '❌ 当前没有搜索词，请直接发送关键词或使用 /pansou 关键词');
        return;
      }
      await handlePansouSearch(chatId, session.keyword);

    } else if (action === 'page') {
      const session = sessions.get(chatId);
      if (!session) return;
      
      const page = parseInt(args[0]);
      session.page = page;
      await sendResults(chatId, session.results, session.categories, page);
      
    } else if (action === 'category') {
      const cat = args.join('|');
      const session = sessions.get(chatId);
      if (!session) return;
      
      const statusMsg = await bot.sendMessage(chatId, `🔍 筛选: ${cat}...`);
      
      const { filtered, categories } = await withScraperTask(async (s) => {
        const fresh = await s.search(session.keyword);
        if (cat === '全部') return { filtered: fresh.results, categories: fresh.categories };
        const map = { '电影': 'movie', '剧集': 'tv', '动漫': 'anime' };
        if (!map[cat]) return { filtered: fresh.results, categories: fresh.categories };
        const scoped = await s.filterByCategory(map[cat]);
        return { filtered: scoped.results, categories: scoped.categories || fresh.categories };
      });
      
      session.results = filtered;
      session.categories = categories;
      session.page = 0;
      
      await bot.deleteMessage(chatId, statusMsg.message_id).catch(() => {});
      await sendResults(chatId, filtered, categories, 0);
      
    } else if (action === 'select') {
      const idx = parseInt(args[0]);
      const session = sessions.get(chatId);
      if (!session) return;
      
      const item = session.results[idx];
      if (!item) {
        await bot.sendMessage(chatId, '❌ 结果已过期，请重新搜索');
        return;
      }
      
      const statusMsg = await bot.sendMessage(chatId, `☁️ 正在提取夸克网盘链接...\n${item.title.substring(0, 50)}`);
      
      const quarkLinks = await withScraperTask(s => s.getQuarkLinks(item.url));
      
      await bot.deleteMessage(chatId, statusMsg.message_id);
      
      if (quarkLinks.length === 0) {
        await bot.sendMessage(chatId, 
          `⚠️ 未找到夸克网盘链接\n` +
          `📌 ${item.title}\n` +
          `🔗 详情页: ${item.url}`
        );
        return;
      }
      
      // Store and send first page. Plain text only: titles may contain Markdown control chars.
      session.state = 'detail';
      session.linkPages = session.linkPages || {};
      session.linkPages.gying = {
        title: item.title,
        source: '📦 GYing：',
        links: quarkLinks,
      };
      session.lastDetail = { title: item.title, quarkLinks };
      await sendLinkPage(chatId, 'gying', 0);
    }
    
  } catch (e) {
    console.error('Callback error:', e);
    if (isClosedError(e)) await resetScraper();
    const message = isClosedError(e)
      ? '浏览器会话刚刚断开，已自动重连。请再点一次。'
      : String(e.message || e).slice(0, 300);
    await bot.sendMessage(chatId, `❌ 操作失败: ${message}`);
  }
});

console.log('GYing Bot started...');
