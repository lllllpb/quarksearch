# GYing Quark Telegram Bot

Telegram bot for searching GYing resources and optional PanSou Quark results.

## Features

- Search GYing by keyword.
- Login to GYing account and extract Quark share links.
- Inline result selection and category filtering.
- Optional PanSou integration via `/pansou keyword`.
- Supports Browserless Chromium through CDP.
- Supports Telegram proxy through HTTP proxy.

## Required services

You need one browserless/chromium service:

```bash
docker run -d --name browserless-chromium \
  -p 3000:3000 \
  -e TOKEN=your-browser-token \
  ghcr.io/browserless/chromium:latest
```

Optional PanSou service:

```bash
# Example only. Use your own PanSou deployment.
# Bot expects: http://host:9981/api/search?kw=keyword
```

## Environment variables

Copy `.env.example` to `.env` and fill values:

```bash
cp .env.example .env
```

| Variable | Required | Example | Notes |
|---|---:|---|---|
| `BOT_TOKEN` | yes | `123:ABC` | Telegram BotFather token |
| `SITE_USER` | yes | `user@example.com` | GYing login email/account |
| `SITE_PASS` | yes | `password` | GYing password |
| `BROWSERLESS_WS_ENDPOINT` | yes | `ws://192.168.1.145:3000?token=xxx` | Browserless CDP endpoint |
| `TELEGRAM_PROXY` | no | `http://192.168.1.145:7890` | Proxy for Telegram API |
| `PANSOU_BASE_URL` | no | `http://192.168.1.145:9981` | PanSou base URL |

## Run with Docker Compose

```bash
docker compose -f docker-compose.release.yml up -d
```

## Run with Docker

```bash
docker run -d --name gying-bot --restart unless-stopped \
  --env-file .env \
  ghcr.io/YOUR_NAME/gying-bot:latest
```

## Commands

- `/search 海绵宝宝` - Search GYing.
- `/pansou 海绵宝宝` - Search PanSou Quark results.
- `/status` - Show bot state.

## Build locally

```bash
docker build -t gying-bot:latest .
```

## Publish image

Docker Hub:

```bash
docker login
docker buildx create --use --name gying-builder 2>/dev/null || docker buildx use gying-builder
docker buildx build --platform linux/amd64,linux/arm64 \
  -t YOUR_DOCKERHUB_USER/gying-bot:latest \
  -t YOUR_DOCKERHUB_USER/gying-bot:1.0.0 \
  --push .
```

GHCR:

```bash
echo YOUR_GITHUB_TOKEN | docker login ghcr.io -u YOUR_GITHUB_USER --password-stdin
docker buildx create --use --name gying-builder 2>/dev/null || docker buildx use gying-builder
docker buildx build --platform linux/amd64,linux/arm64 \
  -t ghcr.io/YOUR_GITHUB_USER/gying-bot:latest \
  -t ghcr.io/YOUR_GITHUB_USER/gying-bot:1.0.0 \
  --push .
```

## Notes

- Do not bake `.env` into the image. `.dockerignore` excludes it.
- Only one container should poll the same Telegram bot token, otherwise Telegram returns `409 Conflict`.
- Browserless is required because GYing uses browser verification.
